import requests
import csv
import os
import json
import time
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import glob
import shutil

# ================= 配置区 =================
ACCESS_TOKEN = 'EAAMyoqUZCW58BQIQeIQipUBwJdxEgRW7bZBZCDb9pycsRqav1wXCcZBfeeLIkUtsr3OYio3x0MDpsqUV3FYoZBi2yy0E3EbWY0hyy8yzNZBWmTAihZBy3KlIGNzOkLkRr3hSxDPe2Q0ZCXAddtAM14BH5uIKaa7E1PfZCipwt70vYwJw7ujymIMX3OjbzPLgAGIYh7wZDZD'
API_VERSION = 'v19.0'

# 指定保存路径
SAVE_FOLDER = r"d:\claude-code\分时数据"
SHOP_DATA_FOLDER = r"d:\claude-code\分时数据\店铺数据源"
QUERY_DATA_FOLDER = r"d:\claude-code\分时数据\查询日期数据"
COMPARE_DATA_FOLDER = r"d:\claude-code\分时数据\环比日期数据"
QUERY_DATA_FOLDER = r"d:\claude-code\分时数据\查询日期数据"
COMPARE_DATA_FOLDER = r"d:\claude-code\分时数据\环比日期数据"

ad_accounts = [
    'act_825022360510809', 'act_1142490878098226', 'act_2118586185580813', 'act_1516366349431274', 'act_892624639793309',
]

csv_headers = [
    'snapshot_time', 'date_start', 'hour',
    'account_name', 'campaign_name',
    'spend', 'impressions', 'clicks', 'link_clicks',
    'cpas_purchase_count',
    'cpas_purchase_count_1d_view',
    'cpas_purchase_count_7d_click',
    'cpas_purchase_value',
    'cpas_purchase_value_1d_view',
    'cpas_purchase_value_7d_click',
    'cpas_roas'
]

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

# ================= 辅助函数 =================

def get_cpas_stats(item):
    p_count = p_count_1d = p_count_7d = 0
    p_value = p_value_1d = p_value_7d = 0

    for a in item.get('catalog_segment_actions', []):
        if a.get('action_type') == 'purchase':
            p_count    = float(a.get('value',    0))
            p_count_1d = float(a.get('1d_view',  0))
            p_count_7d = float(a.get('7d_click', 0))

    for v in item.get('catalog_segment_value', []):
        if v.get('action_type') == 'purchase':
            p_value    = float(v.get('value',    0))
            p_value_1d = float(v.get('1d_view',  0))
            p_value_7d = float(v.get('7d_click', 0))

    return p_count, p_count_1d, p_count_7d, p_value, p_value_1d, p_value_7d

def get_link_clicks(item):
    for a in item.get('actions', []):
        if a.get('action_type') == 'link_click':
            return int(float(a.get('value', 0)))
    return 0

def add_data_labels(ax, x_data, y_data, fmt='{:.1f}', fontsize=6, offset=8, color=None, alpha=0.85):
    """在每个数据点上标注具体数值"""
    for x, y in zip(x_data, y_data):
        if y != 0:
            ax.annotate(fmt.format(y), (x, y),
                       textcoords='offset points',
                       xytext=(0, offset),
                       ha='center', va='bottom',
                       fontsize=fontsize, color=color,
                       alpha=alpha,
                       bbox=dict(boxstyle='round,pad=0.08', facecolor='white', edgecolor='none', alpha=0.55))

def parse_date_input(date_str):
    """解析用户输入的日期，支持多种格式"""
    date_str = date_str.strip()
    formats = ['%Y-%m-%d', '%Y/%m/%d', '%Y%m%d', '%d-%m-%Y', '%d/%m/%Y']

    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt).strftime('%Y-%m-%d')
        except ValueError:
            continue

    raise ValueError(f"无法解析日期格式: {date_str}，请使用 YYYY-MM-DD 格式")

def find_shop_data_file():
    """在店铺数据源文件夹中查找最新的店铺数据文件"""
    pattern = os.path.join(SHOP_DATA_FOLDER, "*.xls*")
    files = glob.glob(pattern)

    if not files:
        return None

    return max(files, key=os.path.getmtime)

def clear_folder(folder_path):
    """清空文件夹中的所有内容"""
    if os.path.exists(folder_path):
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                print(f'删除 {file_path} 时出错: {e}')

def check_shop_data_dates(shop_file, target_dates):
    """检查店铺数据源是否包含目标日期的数据（至少有一条数据即可）"""
    try:
        shopee_df = pd.read_excel(shop_file, sheet_name=1)
        shopee_hourly = shopee_df.iloc[2:].copy()
        shopee_hourly.columns = shopee_df.iloc[2].values
        shopee_hourly = shopee_hourly.iloc[1:].reset_index(drop=True)

        time_col = shopee_hourly.iloc[:, 0]

        # 统计每个日期的数据条数
        date_counts = {}
        for time_str in time_col:
            if pd.notna(time_str) and ' ' in str(time_str):
                date_part = str(time_str).split()[0]
                try:
                    dt = datetime.strptime(date_part, '%d-%m-%Y')
                    date_key = dt.strftime('%Y-%m-%d')
                    date_counts[date_key] = date_counts.get(date_key, 0) + 1
                except:
                    continue

        available_dates = set(date_counts.keys())

        missing_dates = []
        partial_dates = []
        for target_date in target_dates:
            if target_date not in available_dates:
                missing_dates.append(target_date)
            elif date_counts[target_date] < 24:
                partial_dates.append((target_date, date_counts[target_date]))

        # 只要有数据就算通过，即使不是完整24小时
        return len(missing_dates) == 0, missing_dates, available_dates, partial_dates

    except Exception as e:
        print(f"读取店铺数据文件时出错: {e}")
        return False, target_dates, set(), []

def fetch_data(account_id, target_date):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    results = []
    max_retries = 3
    retry_delay = 60

    for attempt in range(max_retries + 1):
        try:
            url = f"https://graph.facebook.com/{API_VERSION}/{account_id}/insights"
            params = {
                'access_token': ACCESS_TOKEN,
                'level': 'campaign',
                'fields': 'campaign_name,account_name,spend,impressions,clicks,date_start,actions,catalog_segment_actions,catalog_segment_value',
                'breakdowns': 'hourly_stats_aggregated_by_advertiser_time_zone',
                'action_attribution_windows': json.dumps(['1d_view', '7d_click']),
                'time_range': json.dumps({"since": target_date, "until": target_date}),
                'limit': 500
            }

            page_count = 0
            after_cursor = None
            page_break = False

            while True:
                if after_cursor:
                    params['after'] = after_cursor

                try:
                    res = requests.get(url, params=params, timeout=30).json()
                except Exception as page_error:
                    print(f"⚠️ 账户 {account_id} 第 {page_count + 1} 页请求异常: {page_error}")
                    if attempt < max_retries:
                        page_break = True
                        break
                    else:
                        return results

                page_count += 1

                if 'error' in res:
                    error_msg = res['error'].get('message', str(res['error']))
                    if 'Application request limit reached' in error_msg or 'rate limit' in error_msg.lower():
                        if attempt < max_retries:
                            print(f"⚠️ 账户 {account_id} 达到API限制，第{attempt+1}次大重试，等待{retry_delay}秒...")
                            time.sleep(retry_delay)
                            page_break = True
                            break
                        else:
                            print(f"❌ 账户 {account_id} API限制重试失败: {error_msg}")
                            return results
                    else:
                        print(f"❌ 账户 {account_id} API 报错: {error_msg}")
                        return results

                data_items = res.get('data', [])
                items_count = len(data_items)
                valid_count = 0

                for item in data_items:
                    spend = float(item.get('spend', 0))
                    if spend <= 0:
                        continue

                    valid_count += 1
                    p_count, p_count_1d, p_count_7d, p_value, p_value_1d, p_value_7d = get_cpas_stats(item)

                    results.append([
                        ts,
                        item.get('date_start'),
                        item.get('hourly_stats_aggregated_by_advertiser_time_zone', ''),
                        item.get('account_name'),
                        item.get('campaign_name'),
                        spend,
                        item.get('impressions', 0),
                        item.get('clicks', 0),
                        get_link_clicks(item),
                        p_count, p_count_1d, p_count_7d,
                        p_value, p_value_1d, p_value_7d,
                        round(p_value / spend, 2) if spend > 0 else 0
                    ])

                print(f"  ✓ 账户 {account_id} 第 {page_count} 页: {items_count} 条原始 / {valid_count} 条有效")

                paging = res.get('paging', {})
                after_cursor = paging.get('cursors', {}).get('after')
                if not after_cursor:
                    break

                time.sleep(1)

            if page_break:
                continue

            return results

        except Exception as e:
            if attempt < max_retries:
                print(f"⚠️ 账户 {account_id} 发生异常，第{attempt+1}次大重试: {e}")
                time.sleep(retry_delay)
            else:
                print(f"❌ 账户 {account_id} 最终失败: {e}")
                return results

    return results

def fetch_hourly_data(target_date, output_folder):
    """抓取指定日期的分时数据"""
    print(f"\n🚀 开始抓取分时数据（{target_date}）: {datetime.now().strftime('%H:%M:%S')}")

    all_data = []
    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = {executor.submit(fetch_data, acc, target_date): acc for acc in ad_accounts}
        for f in as_completed(futures):
            res = f.result()
            if res:
                all_data.extend(res)
            time.sleep(2)

    print(f"📊 汇总结果: 采集到 {len(all_data)} 条分时记录。")

    if all_data:
        file_path = os.path.join(output_folder, f"G2G_Hourly_CPAS_{target_date}.csv")

        while True:
            try:
                with open(file_path, 'w', newline='', encoding='utf-8-sig') as f:
                    writer = csv.writer(f)
                    writer.writerow(csv_headers)
                    writer.writerows(all_data)
                    f.flush()
                print(f"✅ 数据已成功写入: {os.path.basename(file_path)}")
                return file_path
            except PermissionError:
                print(f"\n⚠️  文件被占用（Excel 中打开中）：{os.path.basename(file_path)}")
                input("   请关闭该文件后，按回车键重试...")
    else:
        print("ℹ️  未发现有消耗的广告数据。")
        return None

def generate_dashboard(csv_file, shop_file, target_date, output_folder, end_hour=23,
                       campaign_keyword=None, campaign_include=True, campaign_label=''):
    """生成分时数据看板"""
    label_info = f' [{campaign_label}]' if campaign_label else ''
    file_suffix = f'_{campaign_label}' if campaign_label else ''
    print(f"\n📈 开始生成分时数据看板{label_info}（{target_date}，显示到 {end_hour}:00）...")

    # 读取Facebook广告CSV文件
    df = pd.read_csv(csv_file)

    # 按 campaign 类型拆分
    if campaign_keyword is not None:
        before_count = len(df)
        if campaign_include:
            df = df[df['campaign_name'].str.contains(campaign_keyword, na=False)]
            match_desc = f"包含「{campaign_keyword}」"
        else:
            df = df[~df['campaign_name'].str.contains(campaign_keyword, na=False)]
            match_desc = f"不包含「{campaign_keyword}」"
        print(f"   筛选条件: {match_desc}，{len(df)} 条 / {before_count} 条")
        if len(df) == 0:
            print(f"   ⚠️ 筛选后无数据，跳过。")
            return

    # 按小时汇总Facebook数据
    hourly_summary = df.groupby('hour').agg({
        'spend': 'sum',
        'impressions': 'sum',
        'clicks': 'sum',
        'link_clicks': 'sum',
        'cpas_purchase_count': 'sum',
        'cpas_purchase_count_1d_view': 'sum',
        'cpas_purchase_count_7d_click': 'sum',
        'cpas_purchase_value': 'sum',
        'cpas_purchase_value_1d_view': 'sum',
        'cpas_purchase_value_7d_click': 'sum'
    }).reset_index()

    hourly_summary['hour_num'] = hourly_summary['hour'].str.split(':').str[0].astype(int)
    hourly_summary = hourly_summary.sort_values('hour_num')

    # 筛选到指定的截止时间
    hourly_summary = hourly_summary[hourly_summary['hour_num'] <= end_hour]

    # 读取Shopee店铺数据
    shopee_df = pd.read_excel(shop_file, sheet_name=1)
    shopee_hourly = shopee_df.iloc[2:].copy()
    shopee_hourly.columns = shopee_df.iloc[2].values
    shopee_hourly = shopee_hourly.iloc[1:].reset_index(drop=True)

    time_col = shopee_hourly.iloc[:, 0]
    sales_col = shopee_hourly.iloc[:, 1]

    shopee_data = pd.DataFrame({
        'time_str': time_col,
        'sales_thb_str': sales_col
    })

    # 只提取目标日期的数据
    target_date_obj = datetime.strptime(target_date, '%Y-%m-%d')
    target_date_shopee = target_date_obj.strftime('%d-%m-%Y')

    shopee_data['hour_num'] = shopee_data['time_str'].apply(
        lambda x: int(str(x).split()[-1].split(':')[0]) if pd.notna(x) and ' ' in str(x) and target_date_shopee in str(x) else None
    )

    shopee_data['sales_thb'] = shopee_data['sales_thb_str'].apply(
        lambda x: float(str(x).replace(',', '')) if pd.notna(x) and str(x) != 'nan' else 0
    )

    shopee_data = shopee_data[shopee_data['hour_num'].notna()][['hour_num', 'sales_thb']]

    # 筛选到指定的截止时间
    shopee_data = shopee_data[shopee_data['hour_num'] <= end_hour]

    # 合并数据
    hourly_summary = hourly_summary.merge(shopee_data, on='hour_num', how='left')
    hourly_summary['sales_thb'] = hourly_summary['sales_thb'].fillna(0)

    # 计算指标
    hourly_summary['roas'] = hourly_summary['cpas_purchase_value'] / hourly_summary['spend']
    hourly_summary['roas'] = hourly_summary['roas'].fillna(0)

    hourly_summary['fb_cost_ratio'] = (hourly_summary['spend'] * 6.9 * 4.75 / hourly_summary['sales_thb'] * 100)
    hourly_summary['fb_cost_ratio'] = hourly_summary['fb_cost_ratio'].replace([float('inf'), -float('inf')], 0).fillna(0)

    hourly_summary['fb_gmv_ratio'] = (hourly_summary['cpas_purchase_value'] * 6.9 * 4.75 / hourly_summary['sales_thb'] * 100)
    hourly_summary['fb_gmv_ratio'] = hourly_summary['fb_gmv_ratio'].replace([float('inf'), -float('inf')], 0).fillna(0)

    # 计算点击率 = clicks / impressions
    hourly_summary['click_rate'] = hourly_summary['clicks'] / hourly_summary['impressions'] * 100
    hourly_summary['click_rate'] = hourly_summary['click_rate'].replace([float('inf'), -float('inf')], 0).fillna(0)

    # 创建图表 - 增大画布尺寸以容纳数据标签
    fig, (ax1, ax2, ax3, ax4) = plt.subplots(4, 1, figsize=(18, 20))
    fig.patch.set_facecolor('#FAFAFA')

    # 为每个子图添加浅色背景
    for ax in [ax1, ax2, ax3, ax4]:
        ax.set_facecolor('#F8F9FA')

    # 子图1: Spend, FB Purchase Value + ROAS
    ax1_left = ax1
    ax1_left.set_xlabel('小时', fontsize=11)
    ax1_left.set_ylabel('金额 (USD)', fontsize=11, color='black')
    line1 = ax1_left.plot(hourly_summary['hour_num'], hourly_summary['spend'],
                           marker='o', label='Spend', color='#FF6B6B', linewidth=2.5, markersize=6)
    line2 = ax1_left.plot(hourly_summary['hour_num'], hourly_summary['cpas_purchase_value'],
                           marker='s', label='FB Purchase Value', color='#4ECDC4', linewidth=2.5, markersize=6)
    ax1_left.tick_params(axis='y', labelcolor='black')
    ax1_left.grid(True, alpha=0.3, linestyle='--')

    ax1_right = ax1_left.twinx()
    ax1_right.set_ylabel('ROAS', fontsize=11, color='#95E1D3')
    line3 = ax1_right.plot(hourly_summary['hour_num'], hourly_summary['roas'],
                            marker='^', label='ROAS', color='#95E1D3', linewidth=2.5, markersize=7, linestyle='--')
    ax1_right.tick_params(axis='y', labelcolor='#95E1D3')
    ax1_right.set_ylim(0, max(10, hourly_summary['roas'].max() * 1.2))

    ax1_left.set_xticks(range(0, end_hour + 1))
    ax1_left.set_xticklabels([f'{h:02d}:00' for h in range(end_hour + 1)], rotation=45)
    ax1_left.set_title(f'图1: Spend & FB Purchase Value & ROAS{label_info} ({target_date} 00:00-{end_hour:02d}:00)', fontsize=12, fontweight='bold', pad=10)

    lines1 = line1 + line2 + line3
    labels1 = [l.get_label() for l in lines1]
    ax1_left.legend(lines1, labels1, loc='upper left', fontsize=10, framealpha=0.9)

    # 添加数据标签
    add_data_labels(ax1_left, hourly_summary['hour_num'], hourly_summary['spend'],
                    fmt='${:.0f}', fontsize=6, offset=10, color='#FF6B6B')
    add_data_labels(ax1_left, hourly_summary['hour_num'], hourly_summary['cpas_purchase_value'],
                    fmt='${:.0f}', fontsize=6, offset=-12, color='#4ECDC4')
    add_data_labels(ax1_right, hourly_summary['hour_num'], hourly_summary['roas'],
                    fmt='{:.2f}', fontsize=6, offset=8, color='#95E1D3')

    # 子图2: Shopee Sales, Spend + FB费比
    ax2_left = ax2
    ax2_left.set_xlabel('小时', fontsize=11)
    ax2_left.set_ylabel('金额 (USD)', fontsize=11, color='black')
    line4 = ax2_left.plot(hourly_summary['hour_num'], hourly_summary['sales_thb'] / 4.75 / 6.9,
                           marker='D', label='Shopee Sales (USD)', color='#FFA500', linewidth=2.5, markersize=6)
    line5 = ax2_left.plot(hourly_summary['hour_num'], hourly_summary['spend'],
                           marker='o', label='Spend', color='#FF6B6B', linewidth=2.5, markersize=6)
    ax2_left.tick_params(axis='y', labelcolor='black')
    ax2_left.grid(True, alpha=0.3, linestyle='--')

    ax2_right = ax2_left.twinx()
    ax2_right.set_ylabel('FB费比 (%)', fontsize=11, color='#F38181')
    line6 = ax2_right.plot(hourly_summary['hour_num'], hourly_summary['fb_cost_ratio'],
                            marker='v', label='FB费比', color='#F38181', linewidth=2.5, markersize=7, linestyle='--')
    ax2_right.tick_params(axis='y', labelcolor='#F38181')
    ax2_right.set_ylim(0, max(50, hourly_summary['fb_cost_ratio'].max() * 1.2))

    ax2_left.set_xticks(range(0, end_hour + 1))
    ax2_left.set_xticklabels([f'{h:02d}:00' for h in range(end_hour + 1)], rotation=45)
    ax2_left.set_title(f'图2: Shopee Sales & Spend & FB费比{label_info} ({target_date} 00:00-{end_hour:02d}:00)', fontsize=12, fontweight='bold', pad=10)

    lines2 = line4 + line5 + line6
    labels2 = [l.get_label() for l in lines2]
    ax2_left.legend(lines2, labels2, loc='upper left', fontsize=10, framealpha=0.9)

    # 添加数据标签
    add_data_labels(ax2_left, hourly_summary['hour_num'], hourly_summary['sales_thb'] / 4.75 / 6.9,
                    fmt='${:.0f}', fontsize=6, offset=10, color='#FFA500')
    add_data_labels(ax2_left, hourly_summary['hour_num'], hourly_summary['spend'],
                    fmt='${:.0f}', fontsize=6, offset=-12, color='#FF6B6B')
    add_data_labels(ax2_right, hourly_summary['hour_num'], hourly_summary['fb_cost_ratio'],
                    fmt='{:.1f}%', fontsize=6, offset=8, color='#F38181')

    # 子图3: Shopee Sales, FB Purchase Value + FBGMV占比
    ax3_left = ax3
    ax3_left.set_xlabel('小时', fontsize=11)
    ax3_left.set_ylabel('金额 (USD)', fontsize=11, color='black')
    line7 = ax3_left.plot(hourly_summary['hour_num'], hourly_summary['sales_thb'] / 4.75 / 6.9,
                           marker='D', label='Shopee Sales (USD)', color='#FFA500', linewidth=2.5, markersize=6)
    line8 = ax3_left.plot(hourly_summary['hour_num'], hourly_summary['cpas_purchase_value'],
                           marker='s', label='FB Purchase Value', color='#4ECDC4', linewidth=2.5, markersize=6)
    ax3_left.tick_params(axis='y', labelcolor='black')
    ax3_left.grid(True, alpha=0.3, linestyle='--')

    ax3_right = ax3_left.twinx()
    ax3_right.set_ylabel('FBGMV占比 (%)', fontsize=11, color='#AA96DA')
    line9 = ax3_right.plot(hourly_summary['hour_num'], hourly_summary['fb_gmv_ratio'],
                            marker='*', label='FBGMV占比', color='#AA96DA', linewidth=2.5, markersize=9, linestyle='--')
    ax3_right.tick_params(axis='y', labelcolor='#AA96DA')
    ax3_right.set_ylim(0, max(50, hourly_summary['fb_gmv_ratio'].max() * 1.2))

    ax3_left.set_xticks(range(0, end_hour + 1))
    ax3_left.set_xticklabels([f'{h:02d}:00' for h in range(end_hour + 1)], rotation=45)
    ax3_left.set_title(f'图3: Shopee Sales & FB Purchase Value & FBGMV占比{label_info} ({target_date} 00:00-{end_hour:02d}:00)', fontsize=12, fontweight='bold', pad=10)

    lines3 = line7 + line8 + line9
    labels3 = [l.get_label() for l in lines3]
    ax3_left.legend(lines3, labels3, loc='upper left', fontsize=10, framealpha=0.9)

    # 添加数据标签
    add_data_labels(ax3_left, hourly_summary['hour_num'], hourly_summary['sales_thb'] / 4.75 / 6.9,
                    fmt='${:.0f}', fontsize=6, offset=10, color='#FFA500')
    add_data_labels(ax3_left, hourly_summary['hour_num'], hourly_summary['cpas_purchase_value'],
                    fmt='${:.0f}', fontsize=6, offset=-12, color='#4ECDC4')
    add_data_labels(ax3_right, hourly_summary['hour_num'], hourly_summary['fb_gmv_ratio'],
                    fmt='{:.1f}%', fontsize=6, offset=8, color='#AA96DA')

    # 子图4: Impressions, Clicks + 点击率
    ax4_left = ax4
    ax4_left.set_xlabel('小时', fontsize=11)
    ax4_left.set_ylabel('数量', fontsize=11, color='black')
    line10 = ax4_left.plot(hourly_summary['hour_num'], hourly_summary['impressions'],
                            marker='o', label='Impressions', color='#6C5CE7', linewidth=2.5, markersize=6)
    line11 = ax4_left.plot(hourly_summary['hour_num'], hourly_summary['clicks'],
                            marker='s', label='Clicks', color='#00B894', linewidth=2.5, markersize=6)
    ax4_left.tick_params(axis='y', labelcolor='black')
    ax4_left.grid(True, alpha=0.3, linestyle='--')

    ax4_right = ax4_left.twinx()
    ax4_right.set_ylabel('点击率 (%)', fontsize=11, color='#E17055')
    line12 = ax4_right.plot(hourly_summary['hour_num'], hourly_summary['click_rate'],
                             marker='^', label='点击率', color='#E17055', linewidth=2.5, markersize=7, linestyle='--')
    ax4_right.tick_params(axis='y', labelcolor='#E17055')
    ax4_right.set_ylim(0, max(5, hourly_summary['click_rate'].max() * 1.2))

    ax4_left.set_xticks(range(0, end_hour + 1))
    ax4_left.set_xticklabels([f'{h:02d}:00' for h in range(end_hour + 1)], rotation=45)
    ax4_left.set_title(f'图4: Impressions & Clicks & 点击率{label_info} ({target_date} 00:00-{end_hour:02d}:00)', fontsize=12, fontweight='bold', pad=10)

    lines4 = line10 + line11 + line12
    labels4 = [l.get_label() for l in lines4]
    ax4_left.legend(lines4, labels4, loc='upper left', fontsize=10, framealpha=0.9)

    # 添加数据标签
    add_data_labels(ax4_left, hourly_summary['hour_num'], hourly_summary['impressions'],
                    fmt='{:.0f}', fontsize=6, offset=10, color='#6C5CE7')
    add_data_labels(ax4_left, hourly_summary['hour_num'], hourly_summary['clicks'],
                    fmt='{:.0f}', fontsize=6, offset=-12, color='#00B894')
    add_data_labels(ax4_right, hourly_summary['hour_num'], hourly_summary['click_rate'],
                    fmt='{:.2f}%', fontsize=6, offset=8, color='#E17055')

    plt.suptitle(f'分时数据看板{label_info} - {target_date} (00:00-{end_hour:02d}:00)', fontsize=15, fontweight='bold', y=0.995)
    plt.tight_layout(pad=2.5, h_pad=4.0)

    # 保存图表（覆盖）
    chart_file = os.path.join(output_folder, f"hourly_dashboard{file_suffix}_{target_date}.png")
    plt.savefig(chart_file, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"✅ 图表已保存: {os.path.basename(chart_file)}")

    # 导出汇总数据（覆盖）
    export_df = hourly_summary[['hour', 'spend', 'impressions', 'clicks', 'link_clicks',
                                 'cpas_purchase_count', 'cpas_purchase_count_1d_view',
                                 'cpas_purchase_count_7d_click', 'cpas_purchase_value',
                                 'cpas_purchase_value_1d_view', 'cpas_purchase_value_7d_click',
                                 'sales_thb', 'roas', 'fb_cost_ratio', 'fb_gmv_ratio',
                                 'click_rate']]

    output_csv = os.path.join(output_folder, f"hourly_summary{file_suffix}_{target_date}.csv")
    export_df.to_csv(output_csv, index=False, encoding='utf-8-sig')
    print(f"✅ 汇总数据已保存: {os.path.basename(output_csv)}")

    # 生成汇总表格
    total_spend = hourly_summary['spend'].sum()
    total_fb_purchase_value = hourly_summary['cpas_purchase_value'].sum()
    total_shopee_sales_thb = hourly_summary['sales_thb'].sum()
    total_shopee_sales_usd = total_shopee_sales_thb / 4.75 / 6.9
    total_roi = (total_fb_purchase_value / total_spend) if total_spend > 0 else 0
    total_cost_ratio = (total_spend * 6.9 * 4.75 / total_shopee_sales_thb * 100) if total_shopee_sales_thb > 0 else 0
    total_fbgmv_ratio = (total_fb_purchase_value * 6.9 * 4.75 / total_shopee_sales_thb * 100) if total_shopee_sales_thb > 0 else 0

    # 创建汇总表格图片
    fig_summary, ax_summary = plt.subplots(figsize=(12, 4))
    ax_summary.axis('tight')
    ax_summary.axis('off')

    summary_data = [
        ['指标', '数值'],
        ['总Spend (USD)', f'${total_spend:,.2f}'],
        ['总FB Purchase Value (USD)', f'${total_fb_purchase_value:,.2f}'],
        ['总Shopee Sales (THB)', f'THB {total_shopee_sales_thb:,.2f}'],
        ['总Shopee Sales (USD)', f'${total_shopee_sales_usd:,.2f}'],
        ['总ROI', f'{total_roi:.2f}'],
        ['总FB费比 (%)', f'{total_cost_ratio:.2f}%'],
        ['总FBGMV占比 (%)', f'{total_fbgmv_ratio:.2f}%']
    ]

    table = ax_summary.table(cellText=summary_data, cellLoc='left', loc='center',
                             colWidths=[0.5, 0.5])
    table.auto_set_font_size(False)
    table.set_fontsize(12)
    table.scale(1, 2.5)

    # 设置表头样式
    for i in range(2):
        table[(0, i)].set_facecolor('#4ECDC4')
        table[(0, i)].set_text_props(weight='bold', color='white')

    # 设置数据行样式
    for i in range(1, len(summary_data)):
        for j in range(2):
            if i % 2 == 0:
                table[(i, j)].set_facecolor('#F0F0F0')
            else:
                table[(i, j)].set_facecolor('#FFFFFF')

    plt.title(f'数据汇总表{label_info} - {target_date} (00:00-{end_hour:02d}:00)',
              fontsize=14, fontweight='bold', pad=20)

    # 保存汇总表格图片
    summary_table_file = os.path.join(output_folder, f"summary_table{file_suffix}_{target_date}.png")
    plt.savefig(summary_table_file, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print(f"✅ 汇总表格已保存: {os.path.basename(summary_table_file)}")

def main():
    """主流程"""
    print("=" * 60)
    print("分时数据分析工具")
    print("=" * 60)

    if not os.path.exists(SAVE_FOLDER):
        os.makedirs(SAVE_FOLDER)
    if not os.path.exists(SHOP_DATA_FOLDER):
        os.makedirs(SHOP_DATA_FOLDER)
    if not os.path.exists(QUERY_DATA_FOLDER):
        os.makedirs(QUERY_DATA_FOLDER)
    if not os.path.exists(COMPARE_DATA_FOLDER):
        os.makedirs(COMPARE_DATA_FOLDER)

    # 清空查询日期数据和环比日期数据文件夹
    print("\n🧹 清空输出文件夹...")
    clear_folder(QUERY_DATA_FOLDER)
    clear_folder(COMPARE_DATA_FOLDER)
    print("✅ 文件夹已清空")

    while True:
        print("\n" + "=" * 60)
        print("请输入要查询的日期信息")
        print("=" * 60)

        # 输入查询日期
        while True:
            query_date_str = input("\n请输入查询日期（格式：YYYY-MM-DD，例如 2026-05-15）: ").strip()
            try:
                query_date = parse_date_input(query_date_str)
                break
            except ValueError as e:
                print(f"❌ {e}")

        # 输入环比日期（可选）
        compare_date = None
        while True:
            compare_date_str = input("请输入环比日期（格式：YYYY-MM-DD，直接回车跳过）: ").strip()
            if not compare_date_str:
                print("✅ 跳过环比日期")
                break
            try:
                compare_date = parse_date_input(compare_date_str)
                break
            except ValueError as e:
                print(f"❌ {e}")

        print(f"\n📅 查询日期: {query_date}")
        if compare_date:
            print(f"📅 环比日期: {compare_date}")

        # 检查店铺数据源
        shop_file = find_shop_data_file()
        if not shop_file:
            print(f"\n❌ 错误：未在 {SHOP_DATA_FOLDER} 中找到店铺数据源文件（.xls 或 .xlsx）")
            print("请将店铺数据文件放入该文件夹后重试。")
            input("\n按回车键重新开始...")
            continue

        print(f"\n✅ 找到店铺数据源: {os.path.basename(shop_file)}")

        # 验证日期
        dates_to_check = [query_date]
        if compare_date:
            dates_to_check.append(compare_date)

        has_data, missing_dates, available_dates, partial_dates = check_shop_data_dates(shop_file, dates_to_check)

        if not has_data:
            print(f"\n⚠️ 警告：店铺数据源数据不匹配")
            print(f"缺少以下日期的数据: {', '.join(missing_dates)}")
            print(f"店铺数据源包含的日期: {', '.join(sorted(available_dates))}")
            input("\n按回车键重新输入日期...")
            continue

        print(f"✅ 店铺数据源包含所需日期的数据")

        # 提示部分数据的情况
        if partial_dates:
            for date, count in partial_dates:
                print(f"ℹ️  注意：{date} 仅有 {count} 小时的数据（非完整24小时）")

        # 抓取查询日期的分时数据
        query_csv = fetch_hourly_data(query_date, QUERY_DATA_FOLDER)
        if query_csv:
            generate_dashboard(query_csv, shop_file, query_date, QUERY_DATA_FOLDER)
            generate_dashboard(query_csv, shop_file, query_date, QUERY_DATA_FOLDER,
                               campaign_keyword='种草', campaign_include=True, campaign_label='合创广告')
            generate_dashboard(query_csv, shop_file, query_date, QUERY_DATA_FOLDER,
                               campaign_keyword='种草', campaign_include=False, campaign_label='收割广告')

        # 抓取环比日期的分时数据（如果有）
        if compare_date:
            compare_csv = fetch_hourly_data(compare_date, COMPARE_DATA_FOLDER)
            if compare_csv:
                generate_dashboard(compare_csv, shop_file, compare_date, COMPARE_DATA_FOLDER)
                generate_dashboard(compare_csv, shop_file, compare_date, COMPARE_DATA_FOLDER,
                                   campaign_keyword='种草', campaign_include=True, campaign_label='合创广告')
                generate_dashboard(compare_csv, shop_file, compare_date, COMPARE_DATA_FOLDER,
                                   campaign_keyword='种草', campaign_include=False, campaign_label='收割广告')

        print("\n" + "=" * 60)
        print("✅ 所有任务完成！")
        print("=" * 60)
        print(f"\n生成的文件：")
        print(f"\n【查询日期数据】文件夹：")
        print(f"  - 分时数据: G2G_Hourly_CPAS_{query_date}.csv")
        print(f"  - 汇总表: hourly_summary_{query_date}.csv")
        print(f"  - 图表: hourly_dashboard_{query_date}.png")
        print(f"  - 汇总表格: summary_table_{query_date}.png")
        print(f"  - [合创广告] 汇总表: hourly_summary_合创广告_{query_date}.csv")
        print(f"  - [合创广告] 图表: hourly_dashboard_合创广告_{query_date}.png")
        print(f"  - [合创广告] 汇总表格: summary_table_合创广告_{query_date}.png")
        print(f"  - [收割广告] 汇总表: hourly_summary_收割广告_{query_date}.csv")
        print(f"  - [收割广告] 图表: hourly_dashboard_收割广告_{query_date}.png")
        print(f"  - [收割广告] 汇总表格: summary_table_收割广告_{query_date}.png")

        if compare_date:
            print(f"\n【环比日期数据】文件夹：")
            print(f"  - 分时数据: G2G_Hourly_CPAS_{compare_date}.csv")
            print(f"  - 汇总表: hourly_summary_{compare_date}.csv")
            print(f"  - 图表: hourly_dashboard_{compare_date}.png")
            print(f"  - 汇总表格: summary_table_{compare_date}.png")
            print(f"  - [合创广告] 汇总表: hourly_summary_合创广告_{compare_date}.csv")
            print(f"  - [合创广告] 图表: hourly_dashboard_合创广告_{compare_date}.png")
            print(f"  - [合创广告] 汇总表格: summary_table_合创广告_{compare_date}.png")
            print(f"  - [收割广告] 汇总表: hourly_summary_收割广告_{compare_date}.csv")
            print(f"  - [收割广告] 图表: hourly_dashboard_收割广告_{compare_date}.png")
            print(f"  - [收割广告] 汇总表格: summary_table_收割广告_{compare_date}.png")

        # 询问是否需要调整图表显示时间
        while True:
            adjust_choice = input("\n是否需要调整图表显示的截止时间？(y/n): ").strip().lower()
            if adjust_choice != 'y':
                break

            # 统一输入一个截止小时，应用到所有图表
            while True:
                try:
                    end_hour_str = input(f"\n请输入所有图表显示的截止小时（0-23，例如输入15表示显示到15:00）: ").strip()
                    end_hour = int(end_hour_str)
                    if 0 <= end_hour <= 23:
                        break
                    else:
                        print("❌ 请输入0-23之间的数字")
                except ValueError:
                    print("❌ 请输入有效的数字")

            # 重新生成查询日期的所有图表
            if query_csv:
                generate_dashboard(query_csv, shop_file, query_date, QUERY_DATA_FOLDER, end_hour)
                generate_dashboard(query_csv, shop_file, query_date, QUERY_DATA_FOLDER, end_hour,
                                   campaign_keyword='种草', campaign_include=True, campaign_label='合创广告')
                generate_dashboard(query_csv, shop_file, query_date, QUERY_DATA_FOLDER, end_hour,
                                   campaign_keyword='种草', campaign_include=False, campaign_label='收割广告')

            # 重新生成环比日期的所有图表
            if compare_date and compare_csv:
                generate_dashboard(compare_csv, shop_file, compare_date, COMPARE_DATA_FOLDER, end_hour)
                generate_dashboard(compare_csv, shop_file, compare_date, COMPARE_DATA_FOLDER, end_hour,
                                   campaign_keyword='种草', campaign_include=True, campaign_label='合创广告')
                generate_dashboard(compare_csv, shop_file, compare_date, COMPARE_DATA_FOLDER, end_hour,
                                   campaign_keyword='种草', campaign_include=False, campaign_label='收割广告')

            print(f"\n✅ 所有图表已更新为显示到 {end_hour:02d}:00！")

        # 询问是否继续
        continue_choice = input("\n是否继续分析其他日期？(y/n): ").strip().lower()
        if continue_choice != 'y':
            break

if __name__ == "__main__":
    main()
